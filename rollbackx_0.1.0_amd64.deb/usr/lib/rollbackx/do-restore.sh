#!/bin/sh
# /usr/lib/rollbackx/do-restore.sh
# pending-restore.conf dosyasındaki snapshot yolunu okur ve geri yükler.
# rollbackx-restore.service tarafından erken boot aşamasında çalıştırılır.

set -e

PENDING="/var/lib/rollbackx/pending-restore.conf"
LOG="/var/log/rollbackx-restore.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG"; }

[ -f "$PENDING" ] || { log "pending-restore.conf yok, çıkılıyor."; exit 0; }

SNAP_PATH=$(cat "$PENDING" | tr -d '[:space:]')

if [ -z "$SNAP_PATH" ] || [ ! -d "$SNAP_PATH" ]; then
    log "HATA: Snapshot dizini bulunamadı: '$SNAP_PATH'"
    rm -f "$PENDING"
    exit 1
fi

log "=========================================="
log "Restore başlıyor: $SNAP_PATH"
log "=========================================="

rsync -aHAXx --delete \
    --exclude='/proc/' \
    --exclude='/sys/' \
    --exclude='/dev/' \
    --exclude='/run/' \
    --exclude='/tmp/' \
    --exclude='/var/lib/rollbackx/' \
    --exclude='/var/log/rollbackx-restore.log' \
    --exclude='/lost+found' \
    --exclude='/boot/grub/' \
    "$SNAP_PATH/" / >> "$LOG" 2>&1

log "Restore tamamlandı."

# Marker'ı sil — bir daha çalışmasın
rm -f "$PENDING"

log "Sistem yeniden başlatılıyor..."
systemctl reboot
